
#include <stdio.h>
#include <conio.h>
#include<string.h>
#include<stdlib.h>
struct hostel
{
 char name[20];
 int phno;
 int age;
 char address[50];
 char fathername[50];
 char gender;
 char messcard;
 char bloodgroup[5];
 int registrationnumber;
 }s[100];
void view();
void search();
void delete();
void add();
void fee();
int main()
{

	int a=0,i=0;
    char uname[10],c=' ';
    char pword[10],code[10];
    char user[10]="user";
    char pass[10]="pass";
    do
{
	system("cls");
printf("\n\t\t****************************************************");
printf("\n\t\t*                                                  *");
printf("\n\t\t*       WELCOME TO HOSTEL MANAGEMENT SYSTEM        *");
printf("\n\t\t*                                                  *");
printf("\n\t\t****************************************************");
    printf("\n\t\t                   LOGIN FORM                       ");
    printf(" \n\t               ENTER USERNAME:");
	scanf("%s", &uname);
	printf(" \n\t               ENTER password:");
	while(i<10)
	{
	    pword[i]=getch();
	    c=pword[i];
	    if(c==13) break;
	    else printf("*");
	    i++;
	}
	pword[i]='\0';
	i=0;
		if(strcmp(uname,user)==0 && strcmp(pword,pass)==0)
	{
	printf("  \n\n\n       WELCOME !!!! LOGIN IS SUCCESSFUL\n");
	system("PAUSE");
	break;
	}
	else
	{
		printf("\n        SORRY !!!!  LOGIN IS UNSUCESSFUL\n");
		system("PAUSE");
		a++;

		getch();

	}
}
	while(a<=2);
	if (a>2)
	{
		printf("\nSorry you have entered the wrong username and password for four times!!!");
		getch();
		}
		system("cls");

		menu();
		return 0;
		}
void menu()
{ int ch;

printf("\n\n\t1.ADD NEW STUDENT");
printf("\n\n\t2.SEARCH STUDENT INFORMATION");
printf("\n\n\t3.FEE DETAILS");
printf("\n\n\t4.REMOVE STUDENT");
printf("\n\n\t5.exit ");
printf("\n\n\tEnter your choice(1,2,3,4 OR 5) : ");
scanf("%d",&ch);
switch(ch)
{ case 1: add();
 menu();
 break;
 case 2: search();
 menu();
 break;
 case 3: fee();
 menu();
 break;
 case 4: delete();
 menu();
break;
 case 5: exit(1);
 break;
}}
void fee()
{
 int totalfee;
 int paidfee;
 int balancefee;
 printf("enter the total fee : ");
 scanf("%d",&totalfee);
 printf("enter the paid fee : ");
 scanf("%d",&paidfee);
 if(totalfee==paidfee)
 {
     printf("no fee due");
}else
        {
            balancefee=totalfee-paidfee;
        printf("balance fee to be paid is : %d",balancefee);
     }
 }


void search()
{
 int i,regno;
 char ch;
printf("\nEnter the registration number : ");
scanf("%d",&regno);
for(i=0;i<100;i++)
if(regno==s[i].registrationnumber)
 {
 printf("\n!!!!!!!!RECORD FOUND!!!!!!!!!");

 }
 menu();
 else
 {
 printf("\nsorry,registration number is not matched");
 menu();
}}
void add()
{char ch;
 int i;
 for( i=0;i<2;i++)
 {
 printf("\nEnter the name : ");
 scanf("%s",&s[i].name);
 fflush(stdin);
  printf("\nEnter the student's age : ");
 scanf("%d",&s[i].age);
 fflush(stdin);
 printf("\nEnter the father's name : ");
 scanf("%d",&s[i].fathername);
 fflush(stdin);
 printf("\nEnter the gender : ");
 scanf("%s",&s[i].gender);
 fflush(stdin);
 printf("\nEnter the phone number : ");
 scanf("%d",&s[i].phno);
 fflush(stdin);
 printf("\nEnter the address : ");
 scanf("%s",&s[i].address);
 fflush(stdin);
 printf("\n\Enter the blood group : ");
 scanf("%d",&s[i].bloodgroup);
 fflush(stdin);
 printf("\nEnter the registration no : ");
 scanf("%d",&s[i].registrationnumber);
 fflush(stdin);
 printf("\nenter the mess card type you required(Temporary/permanent) : ");
 scanf("%d",&s[i].messcard);
 fflush(stdin);
 printf("\nDo you want to add more record(y/n) : ");
 scanf("%c",&ch);
 if(ch!='y')
 goto xy;
 xy:break;
 }
}
void delete()
{int i, regno;
 char ch;
printf ("enter the registration number :");
scanf ("%d",&regno);
for (i=0;i<100;i++)
 if(regno==s[i].registrationnumber)
 { printf("\nAre you sure you want to delete this record(y or n) : ");
 scanf("%c",&ch);
 if(ch=='y')
 printf("\nyour record is deleted");
 menu();
 }
 else
 {printf("registration number not matched : ");
 menu();
}}
