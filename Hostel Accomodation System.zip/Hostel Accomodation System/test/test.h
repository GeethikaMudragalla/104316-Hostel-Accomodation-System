#ifndef __TEST_PROJECT_H__
	#define __PROJECT_H__

	int test_main(void);

	#endif
