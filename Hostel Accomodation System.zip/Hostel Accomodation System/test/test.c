#include "unity.h"
void setUp(){}
void tearDown(){}
void test_test(void)
{
}
void test_zero_one(void)
{
}
void test_negative(void)
{
}
int test_main(void)
{
  UNITY_BEGIN();
  RUN_TEST(test_test);
  RUN_TEST(test_zero_one);
  RUN_TEST(test_negative);
  return UNITY_END();
}
